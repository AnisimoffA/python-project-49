from brain_games.scripts.brain_games import main


def logic(func):
    main()
    n = 0
    while n <= 2:
        func()
        n += 1
        if n == 3:
            print(f"Congratulations, {name}")

if __name__ == "__main__":
    logic()


