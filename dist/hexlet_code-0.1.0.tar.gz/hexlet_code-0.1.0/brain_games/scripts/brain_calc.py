from brain_games.game_logic import logic
from games.game_calc import game, name
from random import randint, choice
import prompt

print(__name__)
def main():
    print("chihcichi")
    logic(calc_game)

if __name__ == "__main__":
    print("vfvf")
    main()
