#!/usr/bin/env python3
from brain_games.game_logic import logic
from brain_games.games.game_progression import progression_game

def main():
    logic(progression_game)

if __name__ == "__main__":
    main()
