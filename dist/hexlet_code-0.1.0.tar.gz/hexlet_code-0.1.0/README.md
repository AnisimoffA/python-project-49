### Hexlet tests and linter status:
[![Actions Status](https://github.com/AnisimoffA/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/AnisimoffA/python-project-49/actions)
<a href="https://codeclimate.com/github/AnisimoffA/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/89b5ac243bcf1a7c19b6/maintainability" /></a>